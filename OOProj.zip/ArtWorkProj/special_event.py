class SpecialEvent:
    def __init__(self, event_id, name, location, event_date, price):
        self._event_id = event_id
        self._name = name
        self._location = location
        self._event_date = event_date
        self._price = price

    def get_event_id(self):
        return self._event_id

    def get_name(self):
        return self._name

    def get_location(self):
        return self._location

    def get_event_date(self):
        return self._event_date

    def get_price(self):
        return self._price
