from ticket import Ticket


class GroupTicket(Ticket):
    def __init__(self, ticket_id, date_of_issue, visitor, group_size):
        self._group_size = group_size
        super().__init__(ticket_id, date_of_issue, visitor)
        self._group_size = group_size

    def calculate_price(self):
        if self._group_size >= 15:
            base_price_per_person = Ticket._base_price * 0.5
            total_price = base_price_per_person * self._group_size
            return total_price * (1 + Ticket._vat_rate)
        else:
            return super().calculate_price()

    def get_group_size(self):
        return self._group_size
