from ticket import Ticket


class SpecialEventTicket(Ticket):
    def __init__(self, ticket_id, date_of_issue, visitor, event, special_price):
        self._special_price = special_price
        super().__init__(ticket_id, date_of_issue, visitor)
        self._event = event

    def calculate_price(self):
        if self._visitor.is_eligible_for_discount():
            discounted_price = self._special_price * 0.5
            return discounted_price * (1 + Ticket._vat_rate)
        elif self._visitor.is_free_ticket_eligible():
            return 0
        else:
            return self._special_price * (1 + Ticket._vat_rate)

    def get_event_name(self):
        return self._event.name
