import unittest
from datetime import datetime
from artwork import Artwork
from exhibition import Exhibition
from visitor import Visitor
from group_ticket import GroupTicket
from special_event import SpecialEvent
from special_event_ticket import SpecialEventTicket


class TestMuseumApp(unittest.TestCase):
    def test_artwork_creation(self):
        artwork = Artwork(1, "Freedom", "Jane Smith", "2020", "Modern Art")
        self.assertEqual(artwork.get_title(), "Freedom")

    def test_exhibition_creation(self):
        exhibition = Exhibition(
            1,
            "American Contemporary",
            "Various Artists",
            "2024-01-01",
            "Modern and Contemporary American Art",
            "Metropolitan Museum of Art",
            datetime(2024, 1, 15),
            datetime(2024, 3, 20),
        )
        self.assertEqual(exhibition.get_location(), "Metropolitan Museum of Art")

    def test_visitor_registration(self):
        visitor = Visitor(1, "Donald Trump", "donald@gmail.com", "1946-06-14")
        self.assertEqual(visitor._name, "Donald Trump")

    def test_group_ticket_pricing(self):
        visitor = Visitor(1, "Test User", "test@example.com", "1990-01-01")
        group_ticket = GroupTicket(1, datetime.now(), visitor, 15)
        expected_price = 15 * 63 * 0.5 * 1.05
        self.assertAlmostEqual(group_ticket.get_price(), expected_price)

    def test_special_event_details(self):
        special_event = SpecialEvent(
            1, "New York Art Expo", "Javits Center", datetime(2024, 5, 10), 200
        )
        self.assertEqual(special_event.get_name(), "New York Art Expo")


if __name__ == "__main__":
    unittest.main()
