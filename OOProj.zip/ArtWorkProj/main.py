from datetime import datetime
from artwork import Artwork
from exhibition import Exhibition
from visitor import Visitor
from group_ticket import GroupTicket
from special_event import SpecialEvent
from special_event_ticket import SpecialEventTicket

artwork1 = Artwork(1, "Freedom", "Jane Smith", "2020", "Modern Art")
artwork2 = Artwork(2, "The American Dream", "John Doe", "2018", "Contemporary Art")

exhibition = Exhibition(
    1,
    "American Contemporary",
    "Various Artists",
    "2024-01-01",
    "Modern and Contemporary American Art",
    "Metropolitan Museum of Art",
    datetime(2024, 1, 15),
    datetime(2024, 3, 20),
)

visitor = Visitor(1, "Donald Trump", "donald@gmail.com", "1946-06-14")

visitor.register_visitor()

special_event = SpecialEvent(
    1, "New York Art Expo", "Javits Center", datetime(2024, 5, 10), 200
)

group_ticket = GroupTicket(1, datetime.now(), visitor, 15)
special_event_ticket = SpecialEventTicket(
    2, datetime.now(), visitor, special_event, 250
)

visitor.purchase_ticket(group_ticket)
visitor.purchase_ticket(special_event_ticket)

print(f"Group Ticket Price: {group_ticket.get_price()} USD")
print(f"Special Event Ticket Price: {special_event_ticket.get_price()} USD")
