from datetime import date, datetime


class Visitor:
    def __init__(self, visitor_id, name, email, date_of_birth):
        self._id = visitor_id
        self._name = name
        self._email = email
        self._date_of_birth = datetime.strptime(date_of_birth, "%Y-%m-%d").date()
        self._tickets = []

    def register_visitor(self):
        print(f"Visitor {self._name} registered successfully with email {self._email}.")

    def purchase_ticket(self, ticket):
        self._tickets.append(ticket)
        print(f"Ticket purchased successfully by {self._name}.")

    def get_tickets(self):
        return self._tickets

    def is_eligible_for_discount(self):
        age = self._calculate_age()
        return age < 18 or age > 60

    def is_free_ticket_eligible(self):
        age = self._calculate_age()
        return age < 18 or age > 60

    def _calculate_age(self):
        today = date.today()
        return (
            today.year
            - self._date_of_birth.year
            - (
                (today.month, today.day)
                < (self._date_of_birth.month, self._date_of_birth.day)
            )
        )

    def get_event_name(
        self,
    ):
        return "an event"
