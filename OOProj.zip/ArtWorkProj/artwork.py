class Artwork:
    def __init__(self, id, title, artist, date_of_creation, historical_significance):
        self._id = id
        self._title = title
        self._artist = artist
        self._date_of_creation = date_of_creation
        self._historical_significance = historical_significance

    def get_title(self):
        return self._title

    def get_artist(self):
        return self._artist

    def get_date_of_creation(self):
        return self._date_of_creation

    def get_historical_significance(self):
        return self._historical_significance
