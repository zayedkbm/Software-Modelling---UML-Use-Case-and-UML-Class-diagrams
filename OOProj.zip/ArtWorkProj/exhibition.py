from artwork import Artwork


class Exhibition(Artwork):
    def __init__(
        self,
        id,
        title,
        artist,
        date_of_creation,
        historical_significance,
        location,
        start_date,
        end_date,
    ):
        super().__init__(id, title, artist, date_of_creation, historical_significance)
        self._location = location
        self._start_date = start_date
        self._end_date = end_date

    def get_location(self):
        return self._location

    def get_start_date(self):
        return self._start_date

    def get_end_date(self):
        return self._end_date
