from ticket import Ticket


class ExhibitionTicket(Ticket):
    def __init__(self, ticket_id, date_of_issue, visitor, exhibition):
        super().__init__(ticket_id, date_of_issue, visitor)
        self._exhibition = exhibition

    def calculate_price(self):
        return super().calculate_price()

    def get_exhibition_details(self):
        return f"Exhibition: {self._exhibition.get_title()} at {self._exhibition.get_location()} from {self._exhibition.get_start_date()} to {self._exhibition.get_end_date()}"
