class Ticket:
    _base_price = 63
    _vat_rate = 0.05

    def __init__(self, ticket_id, date_of_issue, visitor):
        self._ticket_id = ticket_id
        self._date_of_issue = date_of_issue
        self._visitor = visitor
        self._price = self.calculate_price()

    def calculate_price(self):
        if self._visitor.is_eligible_for_discount():
            return (Ticket._base_price / 2) * (1 + Ticket._vat_rate)
        elif self._visitor.is_free_ticket_eligible():
            return 0
        else:
            return Ticket._base_price * (1 + Ticket._vat_rate)

    def get_price(self):
        return self._price
